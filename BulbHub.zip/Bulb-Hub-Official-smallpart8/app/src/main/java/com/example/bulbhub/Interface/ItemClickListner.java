package com.example.bulbhub.Interface;

import android.view.View;

public interface ItemClickListner {

    void onClick (View view, int Position, boolean isLongClick);
}
