package com.example.bulbhub.Pbulb;

import com.example.bulbhub.Bulb.Users;

public class Prevalent {

    public static Users currentOnlineUser; //private to public

    //2
    public static final String UserPhoneKey = "UserPhone";
    //3
    public static final String UserPasswordKey = "UserPassword";
}
